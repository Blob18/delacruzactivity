// routes/myroutes.js

const express = require('express');
const Course = require('../models/schema'); 

const router = express.Router();

// Route to get courses with their names and specializations
router.get('/courses', async (req, res) => {
    try {
      
        const courses = await Course.find({})
            .select('description program -_id');

        if (!courses || courses.length === 0) {
            return res.status(404).send({ message: "No courses found" });
        }

       
        const formattedCourses = courses.map(course => ({
            Name: course.description,
            Specialization: course.program,
        }));

        res.json(formattedCourses);
    } catch (error) {
        res.status(500).send(error);
    }
});

// Route to get backend courses based on a category or similar attribute
router.get('/backend-courses', async (req, res) => {
    try {
        
        const backendCourses = await Course.find({ category: 'Backend' })
            .select('description program -_id');

        if (!backendCourses || backendCourses.length === 0) {
            return res.status(404).send({ message: "No backend courses found" });
        }

        
        const formattedCourses = backendCourses.map(course => ({
            Name: course.description,
            Specialization: course.program,
        }));

        res.json(formattedCourses);
    } catch (error) {
        res.status(500).send(error);
    }
});

router.get('/bsis/all', async (req, res) => {
    try {
        const bsisCourses = await Course.find({ program: 'BSIS' })
            .select('description -_id'); 

        if (!bsisCourses || bsisCourses.length === 0) {
            return res.status(404).send({ message: "No BSIS courses found" });
        }

        const formattedCourses = bsisCourses.map(course => ({
            Name: course.description
        }));

        res.json(formattedCourses);
    } catch (error) {
        res.status(500).send(error);
    }
});

router.get('/bsit/all', async (req, res) => {
    try {
        const bsitCourses = await Course.find({ program: 'BSIT' })
            .select('description -_id');

        if (!bsitCourses || bsitCourses.length === 0) {
            return res.status(404).send({ message: "No BSIT courses found" });
        }

        const formattedCourses = bsitCourses.map(course => ({
            Name: course.description
        }));

        res.json(formattedCourses);
    } catch (error) {
        res.status(500).send(error);
    }
});


module.exports = router;
