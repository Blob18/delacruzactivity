// models/schema.js
const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  code: String,
  description: String,
  program: String,
  year: String,
  units: Number,
  tags: [String],
  category: [String],
});

const Course = mongoose.model('Course', courseSchema);

module.exports = Course;
